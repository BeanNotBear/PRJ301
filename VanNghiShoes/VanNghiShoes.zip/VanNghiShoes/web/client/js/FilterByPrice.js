
function filterByChange(floor, celling) {
    console.log(floor);
    console.log(celling);
    
    var prices = {
        floor: floor,
        celling: celling
    };
    
    var url = contextPath+'/category'
    
    $.ajax({
        url: url,
        type: "POST",
        data: prices,
        cache: false,
        success: function (data) {
            if (data.status === "success") {
               window.location.reload();
            }
        }
    });
}