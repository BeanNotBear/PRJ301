function popUp(element) {
    alert(element);
}