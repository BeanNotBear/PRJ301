let itemDetails;

function getProductDetail(itemJSON) {
    console.log(itemJSON);
    itemDetails = itemJSON;
}