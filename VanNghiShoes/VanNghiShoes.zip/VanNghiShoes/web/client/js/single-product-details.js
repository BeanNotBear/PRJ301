function singleProductDetails() {
    console.log(itemDetails);
//    document.getElementById('productName-detail').innerHTML = itemDetails.productName;
}