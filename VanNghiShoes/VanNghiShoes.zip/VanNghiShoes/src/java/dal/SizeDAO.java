/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import context.DBContext;
import java.util.List;
import model.Size;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nghin
 */
public class SizeDAO extends DBContext {

    public List<Size> getAll() {
        List<Size> sizes = new ArrayList<>();
        String query = "SELECT [ID]\n"
                + "      ,[Size]\n"
                + "  FROM [ShoesShopDB].[dbo].[Size]";
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            Size size = null;
            while (rs.next()) {                
                size = new Size(rs.getInt(1)
                        , rs.getFloat(2));
                sizes.add(size);
            }
            return sizes;
        } catch (SQLException ex) {
            Logger.getLogger(SizeDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public static void main(String[] args) {
        SizeDAO d = new SizeDAO();
        System.out.println(d.getAll().get(0).getSize());
    }
    
}
